"""The request path (§5): auth → repo marker → turn → Guard-lite → budget → decide → floor →
score → provider → routing event. Providers are injected; nothing here touches the network.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from .auth import TokenAuth
from .budget import BudgetGate
from .decide import (
    PoolScore,
    TurnTracker,
    message_hash,
    mode_from,
    pick_pool,
    rules_answers,
)
from .events import EventLog, RoutingEvent
from .guard import redact_messages, redact_tools
from .learn import intake
from .markers import RepoPolicy, repo_policy
from .memory import OpenVikingMemory

AUTO = "xc/auto"


class ProviderError(Exception):
    pass


@dataclass(frozen=True)
class Completion:
    text: str
    tokens_in: int
    tokens_out: int
    cost_micro_usd: int
    failover: bool = False
    # Tool calls the model asked for (§7 dsh jobs): passed through untouched.
    tool_calls: tuple[dict, ...] | None = None


Provider = Callable[..., Completion]  # (pool, messages[, tools]) -> Completion


@dataclass(frozen=True)
class Request:
    token: str | None
    model: str
    messages: list[dict]
    session: str
    cwd: str | None = None
    remote_url: str | None = None
    tools: list[dict] | None = None
    tool_choice: dict | str | None = None


@dataclass
class Result:
    status: int
    pool: str | None = None
    text: str = ""
    event: RoutingEvent | None = None
    detail: str = ""
    tool_calls: tuple | None = None


@dataclass
class PoolConfig:
    provider: str
    est_cost_micro_usd: int


@dataclass
class Router:
    auth: TokenAuth
    pools: dict[str, PoolConfig]
    scores: dict[str, PoolScore]
    healthy: Callable[[], set[str]]
    budget: BudgetGate
    provider: Provider
    events: EventLog
    role_by_prompt_hash: dict[str, str] = field(default_factory=dict)
    repo_overrides: dict[str, RepoPolicy] = field(default_factory=dict)
    pending_dir: Path = Path("/var/lib/xcloud/xccode/learn/pending")
    memory: OpenVikingMemory | None = None
    # Live scores (§8): when set, consulted per request so a weekly `xccode bench --apply` run
    # takes effect without reloading the service. None: the static `scores` dict is used.
    scores_live: Callable[[], dict[str, PoolScore]] | None = None
    lam: float = 0.2
    mu: float = 0.1
    tracker: TurnTracker = field(default_factory=TurnTracker)

    def learn(self, digest: dict) -> tuple[bool, list[str]]:
        """The ``/learn`` intake: verifier-lite gates the digest, then it is written to pending."""
        return intake(self.pending_dir, digest)

    def handle(self, req: Request, now: float | None = None) -> Result:
        now = time.time() if now is None else now
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))
        day = ts[:10]

        agent = self.auth.agent_for(req.token)
        if agent is None:  # unauthenticated callers leave no event: nothing to attribute it to
            return Result(401, detail="bad token")

        user_text = next((m["content"] for m in reversed(req.messages)
                          if m.get("role") == "user" and isinstance(m.get("content"), str)), "")
        sys_text = next((m["content"] for m in req.messages
                         if m.get("role") == "system" and isinstance(m.get("content"), str)), "")
        role = "unknown"
        if sys_text:
            role = self.role_by_prompt_hash.get(message_hash(sys_text), "unknown")
        mh = message_hash(user_text)

        def done(status: int, decider: str, outcome: str, mode=None, pool=None, hits=(),
                 comp: Completion | None = None, ms: int = 0, text="", cost: int | None = None,
                 detail="") -> Result:
            ev = RoutingEvent(
                ts=ts, agent=agent, xc_agent_role=role, decider=decider, mode=mode, pool=pool,
                message_hash=mh, guard_hits=tuple(hits), outcome=outcome,
                tokens_in=comp.tokens_in if comp else 0, tokens_out=comp.tokens_out if comp else 0,
                cost_micro_usd=cost if cost is not None else (comp.cost_micro_usd if comp else 0),
                failover=comp.failover if comp else False, latency_ms=ms,
                tool_count=len(req.tools) if req.tools else 0)
            self.events.write(ev)
            return Result(status, pool, text, ev, detail)

        policy = repo_policy(req.cwd, req.remote_url, self.repo_overrides)
        if policy is RepoPolicy.SECRET:
            return done(403, "refused", "refused:secret-repo", detail="repository marked secret")

        messages, hits = redact_messages(req.messages)
        # Tools are tool definitions (§7): definitions can embed secrets too, so they pass
        # Guard-lite as well before the provider sees them (advisor O4).
        tools, tool_hits = redact_tools(req.tools)
        hits = hits + tuple(h for h in tool_hits if h not in hits)
        redacted_user = next((m["content"] for m in reversed(messages)
                              if m.get("role") == "user" and isinstance(m.get("content"), str)), "")

        answers = rules_answers(redacted_user)
        mode: str | None = None

        if req.model != AUTO:  # the operator's own pinned choice: passed through, floor not applied
            if req.model not in self.pools:
                return done(400, "refused", "refused:unknown-model", hits=hits, detail=req.model)
            pool, decider = req.model, "pinned"
        elif (sticky := self.tracker.sticky(req.session, user_text)) is not None \
                and sticky in self.healthy():
            pool, decider = sticky, "sticky"
        else:
            decider = "rules"
            mode = mode_from(answers)
            scores = self.scores_live() if self.scores_live is not None else self.scores
            pool, why = pick_pool(
                mode, answers, role, self.healthy(), scores, self.lam, self.mu)
            if pool is None:
                return done(503, decider, f"refused:{why}", mode=mode, hits=hits,
                            detail=why)

        cfg = self.pools[pool]
        if not self.budget.allows(day, agent, cfg.provider, cfg.est_cost_micro_usd):
            return done(429, decider, "refused:budget", mode=mode, pool=pool, hits=hits,
                        detail="budget")

        start = time.monotonic()
        try:
            # Tools go through (redacted) only when the caller sent them — the Provider protocol
            # stays two-argument for simple integrations and tests.
            if tools is not None:
                comp = self.provider(pool, messages, tools=tools, tool_choice=req.tool_choice)
            else:
                comp = self.provider(pool, messages)
        except ProviderError as e:
            ms = int((time.monotonic() - start) * 1000)
            return done(502, decider, "error:provider", mode=mode, pool=pool, hits=hits,
                        ms=ms, detail=str(e))
        ms = int((time.monotonic() - start) * 1000)
        # OmniRoute's OpenAI-compatible response has no cost field; fall back to the configured
        # per-request estimate so the daily/per-provider/per-agent caps actually accumulate. The
        # budget and the routing event record the same figure.
        charged = comp.cost_micro_usd or cfg.est_cost_micro_usd
        self.budget.record(day, agent, cfg.provider, charged)
        if decider != "pinned":
            self.tracker.remember(req.session, user_text, pool)
        out = done(200, decider, "ok", mode=mode, pool=pool, hits=hits, comp=comp, ms=ms,
                   cost=charged, text=comp.text)
        out.tool_calls = tuple(comp.tool_calls) if comp.tool_calls else None
        return out
